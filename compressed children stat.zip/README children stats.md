Data visualization on children stats


## FAQ

Insights of visualisation

The Data includes Medical information of children aged between 5-11 (considered age group in years,as there was no mention).It also contained the information of adults also.All the information of the clients was merged in this data.The data was not clearly divide into groups based on age or on disease.The parameters were not used for height,weight(like cms,inchs).The proper parameters for tests were not mentioned(like on what basis it is considered as normal,average or abnormal,whether there are seperate limits for children or adults etc). The data was not specific and gave blurred information.

what was done

Firstly,the data was too confusing,as it included information related to adults as well as children.The given data contained 23 rows and 127 columns.Most of the columns only had information about adults,such columns were dropped from the data.Only columns which were relevant to the mentioned age group were kept.The columns with no value were removed.Duplicates were also removed.The data was then sorted based on age and height.The First letter of the names and gender were capitalized as they were in small letters.After,cleansing the data there were 23 rows and 32 columns.The Bar graph was plotted by keeping Name as constant(x axis) and other headings as Variables(y axis).


Why it was done

The data contained more information which was irrelevant for the age group mentioned.hence,there was a need to cleanse the data.  



