
Data Visualization.

## FAQ

what are the insights from the visualization

The data is about Supply chain management.It includes the information about the demand for vegetarian and non-vegetarian products.The data includes the consumption of products based on cities and exports done to the other countries on specific period.


what was done

To get the clear interpretation, Data cleansing was done.Firstly, the data was sorted based on the products and then the repeated values were removed.The data with no values were dropped from the file.Lastly,the graph was plotted using scatter plot,based on Units(y axis) and Product description(x axis).Before data cleansing there were 111 rows and 4 columns.After cleansing the data,the rows were reduced to 99 with the same number of columns.


why was it done

To avoid the misinterpretation of data and to get a clear view about consumption of products.



what else can be done

It would have been better if the data was more specific about the Units (as in no parameters were provided like grams,kilograms etc.).All the products were provided in a single column,no bifurcation was done (as in Seafood,Meats,Fruits,Dryfruits etc.).The Locations were also not bifurcated,they were also provided under one column whereas they can be divided based on states,regions or countries.
